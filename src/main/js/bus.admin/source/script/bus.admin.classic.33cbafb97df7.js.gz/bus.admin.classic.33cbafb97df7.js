qx.$$packageData['4']={"locales":{},"resources":{"qx/icon/Oxygen/32/status/dialog-information.png":[32,32,"png","qx"]},"translations":{}};
